#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "queue.h"
#include "stack.h"


/*
 * Define your call struct here.
 */




int main(int argc, char const *argv[]) {
  
	return 0;
}
